# HIDPS Agent

## Description

The HIDPS Agent is a lightweight, host-based intrusion detection and prevention system agent. It is designed to be installed on a Linux system to monitor its activity, collect logs, and report back to a central monitoring server. The agent can also receive and execute commands from the server, allowing for remote administration and response.